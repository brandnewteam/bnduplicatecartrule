$(document).ready(function () {
  $('.select2 select').select2();
});
