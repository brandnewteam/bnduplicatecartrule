# Duplicate Cart Rule

PrestaShop module: select a cart rule (coupon/voucher/discounts) and massively duplicate it.

## Credits

Made by [Brand New srl](http://brandnew.sm).
